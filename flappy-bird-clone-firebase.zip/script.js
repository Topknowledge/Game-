let score = 0;
let highScore = localStorage.getItem('flappyHighScore') || 0;
document.getElementById('highscore').innerText = highScore;

function startGame() {
  score = 0;
  document.getElementById('score').innerText = score;
  const interval = setInterval(() => {
    score++;
    document.getElementById('score').innerText = score;
    if (score >= 10) { // example end condition
      clearInterval(interval);
      saveScore(score);
    }
  }, 1000);
}

function saveScore(score) {
  if (score > highScore) {
    highScore = score;
    localStorage.setItem('flappyHighScore', highScore);
    document.getElementById('highscore').innerText = highScore;
  }

  const userScore = {
    score: score,
    time: new Date().toISOString()
  };

  const scoreRef = db.ref('flappy-scores').push();
  scoreRef.set(userScore);

  const board = JSON.parse(localStorage.getItem('flappyBoard') || '[]');
  board.push({ ...userScore, time: new Date().toLocaleString() });
  board.sort((a, b) => b.score - a.score);
  board.splice(10);
  localStorage.setItem('flappyBoard', JSON.stringify(board));
  updateLeaderboard();
}

function updateLeaderboard() {
  const board = JSON.parse(localStorage.getItem('flappyBoard') || '[]');
  const list = document.getElementById('leaderboardList');
  list.innerHTML = '';
  board.forEach((entry, i) => {
    const li = document.createElement('li');
    li.innerText = `#${i + 1}: ${entry.score} (${entry.time})`;
    list.appendChild(li);
  });
}

function shareScore() {
  const text = \`I scored \${score} in Flappy Bird Clone! Play now: https://yourdomain.com\`;
  const shareUrl = \`https://twitter.com/intent/tweet?text=\${encodeURIComponent(text)}\`;
  window.open(shareUrl, '_blank');
}
